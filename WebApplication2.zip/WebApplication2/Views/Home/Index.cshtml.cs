using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.Home
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
