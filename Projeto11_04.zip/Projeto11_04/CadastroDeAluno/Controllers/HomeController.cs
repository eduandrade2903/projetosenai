﻿using CadastroDeAluno.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CadastroDeAluno.Controllers
{
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Listar()
        {
            return View("Listagem", Aluno.listagem);
        }

        public IActionResult Salvar(Aluno aluno)
        {
            if (aluno.Id == 0)
            {
                aluno.Id = Aluno.listagem.Count + 1;
                Aluno.listagem.Add(aluno);
                return RedirectToAction("Listar");

            }
            else
            {
                Aluno alunoAtualizado = Aluno.listagem[aluno.Id];
                alunoAtualizado.Nome = aluno.Nome;
                alunoAtualizado.Curso = aluno.Curso;

                Aluno.listagem[aluno.Id] = alunoAtualizado;
                return View("Listar"); 
            }
           

        }
        public IActionResult Formulario()
        {
            return View();
        }

        public IActionResult FormularioEditar(int Id)
        {
            Aluno alunoBusca = Aluno.listagem[Id];


            return View("Formulario", alunoBusca);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}