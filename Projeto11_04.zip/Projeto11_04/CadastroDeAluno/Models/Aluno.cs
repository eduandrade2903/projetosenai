﻿namespace CadastroDeAluno.Models

{
    public class Aluno
    {
    public int Id{ get; set;}
        
    public string Nome{ get; set;}

    public string Curso{ get; set;}
    
    public static List<Aluno> listagem = new List<Aluno>();

        static Aluno()
        {
            Aluno.listagem.Add(new Aluno{ Id = 1, Nome = "Edjalma", Curso = "TDS"});
            Aluno.listagem.Add(new Aluno{Id = 2, Nome = "Eduardo", Curso = "TDS"});
            Aluno.listagem.Add(new Aluno{ Id = 3, Nome = "Bruno", Curso = "TDS" });
        }
    }

}

